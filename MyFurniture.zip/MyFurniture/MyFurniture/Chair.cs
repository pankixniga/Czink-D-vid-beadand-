﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MyFurniture
{
    internal class Chair:Furniture
    {
        // Alapértékek
        const double chairFactor = 1.2;
        const string type = "Chair";
        const int legs = 4;
        const int id = 145;
        //
        //
        //
        //getPrice metódus
        public override double getPrice()
        {
            return base.getPrice() * chairFactor;
        }
        //
        //
        //
        //getId metódus
        public override int getId()
        {
            return id;
        }
        //
        //
        //
        //getType metódus
        public override string getType()
        {
            return type;
        }
        //
        //
        //
        //Egyéb információk lekérdezése
        public override int getLegs()
        {
            return legs;
        }

    }
}
