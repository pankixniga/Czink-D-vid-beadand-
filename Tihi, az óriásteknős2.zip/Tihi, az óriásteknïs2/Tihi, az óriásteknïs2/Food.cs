﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Tihi__az_óriásteknős2
{
    internal class Food
    {
        int tapertek = 0;
        int size = 0;

        public virtual int value()
        {
            return tapertek;
        }




    }
}
