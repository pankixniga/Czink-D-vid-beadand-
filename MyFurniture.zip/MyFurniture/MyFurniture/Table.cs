﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MyFurniture
{
    internal class Table:Furniture
    {
        // Alapértékek
        const double tableFactor = 0.3;
        const string type = "Table";
        const int id = 123;
        const int height = 200;
        //
        //
        //
        // getPrice
        public override double getPrice()
        {
            return base.getPrice() * tableFactor;
        }
        //
        //
        // Egyéb információk lekérdezése
        public override int getHeight()
        {
            return height;
        }
        public override int getId()
        {
            return id;
        }
        //Vége
        //
        //
        // Típus lekérdezés
        public override string getType()
        {
            return type;
        }
    }
}
