﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MyFurniture
{
    internal class Furniture
    {
        //Alapértékekek
        const int basePrice = 25000;
        const int id = 0;
        const string type = "";
        //
        //Egyéb tulajdonságok
        const int wide = 0;
        const int legs = 0;
        const int length = 0;
        const int height = 0;
        //
        //
        //
        //getPrice metódus
        public virtual double getPrice()
        {
            return basePrice;
        }
        //metódus vége
        //
        //
        //getType metódus
        public virtual string getType()
        {
            return  type;
        }
        //metódus vége
        //
        // 
        //getId metódus
        public virtual int getId()
        {
            return id;
        }
        //metódus vége
        //
        //
        //getHeight metódus
        public virtual int getHeight()
        {
            return height;
        }
        //metódus vége
        //
        //
        //getWide metódus
        public virtual int getWide()
        {
            return wide;
        }
        //metódus vége
        //
        //
        //getLenghth Metódus
        public virtual int getLength()
        {
            return length;
        }
        //metódus vége
        //
        //
        //getLegs metódus
        public virtual int getLegs()
        {
            return legs;
        }
        // metódus vége
    }
}
