﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Hunter
{
    internal class Squirrel:Animal
    {
        //
        const string animalType = "Squirrel";
        const double squirrelFactor = 1.2;
        //Kiiratás
        //
        public override string getType()
        {
            return "Típus: " + animalType;
        }
        //
        //
        //Értékmeghatározás
        public override double getPrice()
        {
            return base.getPrice() * squirrelFactor;
        }
        //
    }
}
