﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MyFurniture
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Furniture[] Butorok = new Furniture[4];
            Butorok[0] = new Table();
            Butorok[1] = new Bed();
            Butorok[2] = new Chair();

            //Sajnos nem igazán tudom ,h h kéne megcsinálni a kiiratás metódust, illetve, "profibban" ,h egyes búturoknál ne írjon ki 0-at annál a tulajdonságnál, ami nincsen neki. 
            // pl. Az asztalnál a lábakat nem kéri, de kiiratásnál 0-at ad vissza és azt a 0-at ne írja ki és ezt metódusban elhelyezve. Az előző pár órán nem voltam, mert beteg voltam
            //és a teamsben felrakott példák nem annyira egyértelműek és a neten nem igazán találok olyan segédletet, ami felhasználható lett volna ebben a feladatban.

            for (int i = 0; i < Butorok.Length; i++)
            {
                Console.WriteLine("NAME: {0}",Butorok[i].getType());
                Console.WriteLine("Price: {0}",Butorok[i].getPrice());
                if (Butorok[i].getLegs() > 1)
                {
                    Console.WriteLine("lábak száma: {0}", Butorok[i].getLegs());
                }
                if (Butorok[i].getLength() > 1)
                {
                    Console.WriteLine("Hosszúság: {0} CM", Butorok[i].getLength());
                }
                if (Butorok[i].getWide() > 1)
                {
                    Console.WriteLine("Szélesség: {0} CM", Butorok[i].getWide());
                }
                if (Butorok[i].getHeight() > 1)
                {
                    Console.WriteLine("Magasság: {0} CM", Butorok[i].getHeight());
                }
                Console.WriteLine("ID: {0}\n",Butorok[i].getId());
            }

            //Kiiratás vége, nem tudom ,h kéne máshogy ezt megoldani, nem voltam az előző héten, mikor ezt az anyagot vettük, meg ezen a héten sem!!
        }
    }
}
