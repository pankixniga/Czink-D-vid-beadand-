﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Hunter
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Tömb létrehozása
            Animal[] Animals =new Animal[5];
            //
            Animals[0]=new Squirrel();
            Animals[1] = new PolarBear();
            Animals[2] = new Rabbit();
            Animals[3] = new Squirrel();
            Animals[4] = new Rabbit();
            // teljes összeg
            int összeg = 0;

            //Kiiratás
            for (int i = 0; i < Animals.Length; i++)
            {
                Console.WriteLine(Animals[i].getType() + " " + Animals[i].getPrice());
                összeg = összeg + (int)Animals[i].getPrice();
            }
            Console.WriteLine("Az egész prém teljes értéke: {0}",összeg);
            //Vége

            Console.ReadKey();
        }
    }
}
