﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Hunter
{
    internal class Animal
    {
        // Alapérték megadása
        const string animalType = "";
        const int basePrice = 100000;
        // Alapérték vége
        //
        //
        //getType metódus
        public virtual string getType()
        {
            return "Típus: " + animalType;
        }
        //getType metódus vége
        //
        //
        //getPrice metódus 
        public virtual double getPrice()
        {
            return basePrice;
        }
       //getPrice metódus vége
    }
}
