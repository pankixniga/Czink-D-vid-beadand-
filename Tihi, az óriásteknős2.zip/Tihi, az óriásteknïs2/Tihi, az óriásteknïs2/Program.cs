﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Tihi__az_óriásteknős2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int összesen = 0;
            Food[] allatok = new Food[3];
            allatok[0] = new Crab(10);
            allatok[1] = new Salad();
            allatok[2] = new Crab(7);


            for (int i = 0; i < allatok.Length; i++)
            {
                Console.WriteLine(allatok[i].value());
                összesen = összesen + allatok[i].value();
            }
            Console.WriteLine("A teljes összeg: {0}",összesen);

            Turtle tihi = new Turtle();

            tihi.eat(ref összesen);
        }
    }
}
