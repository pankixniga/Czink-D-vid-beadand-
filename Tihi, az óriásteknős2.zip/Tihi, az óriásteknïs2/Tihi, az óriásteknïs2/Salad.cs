﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Tihi__az_óriásteknős2
{
    internal class Salad:Food
    {
        int tapertek = 10;

        public override int value()
        {
            return tapertek;
        }
    }
}
