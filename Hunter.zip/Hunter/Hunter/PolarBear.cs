﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Hunter
{
    internal class PolarBear:Animal
    {
        //
        const double polarBearFactor = 2.4;
        const string animalType = "PolarBear";
        //Értékmeghatározás
        //
        public override double getPrice()
        {
            return base.getPrice() * polarBearFactor;
        }
        //Kiiratás
        //
        public override string getType()
        {
            return "Típus: " + animalType;
        }
        //
    }
}
