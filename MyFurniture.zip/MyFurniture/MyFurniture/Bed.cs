﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MyFurniture
{
    internal class Bed:Furniture
    {
        // Alapértékek
        const double bedFactor = 2.4;
        const string type = "Bed";
        const int wide = 200;
        const int id = 13;
        const int length = 270;
        //
        //
        // getPrice metódus
        public override double getPrice()
        {
            return base.getPrice() * bedFactor;
        }
        //
        //
        //
        // getId metódus
        public override int getId()
        {
            return id;
        }
        //
        //
        //
        //getType metódus
        public override string getType()
        {
            return type;
        }
        //
        //
        //
        // Egyéb információk lekérdezése
        public override int getWide()
        {
            return wide;
        }
        public override int getLength()
        {
            return length;
        }

    }
}
