﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Hunter
{
    internal class Rabbit:Animal
    {
        //
        const string animalType = "Rabbit";
        const double rabbitFactor = 0.3;
        //Kiiratás
        //
        public override string getType()
        {
            return "Típus: " + animalType;
        }
        //
        //Értékmeghatározás
        public override double getPrice()
        {
            return base.getPrice() * rabbitFactor;
        }
        //
    }
}
