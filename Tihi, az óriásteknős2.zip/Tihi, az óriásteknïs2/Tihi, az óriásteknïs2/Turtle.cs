﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Tihi__az_óriásteknős2
{
    internal class Turtle
    {
        int happiness = 0;
        int fedLevel = 0;

        public void eat(ref int összesen)
        {
            fedLevel = összesen;

            if(fedLevel < 500)
            {
                happiness = összesen * 2;
            }
            else
            {
                happiness = happiness - (összesen * 2);
            }
            Console.WriteLine("A boldogság {0}, a fedlevel  {1}", happiness,fedLevel);
        }
    }
}
